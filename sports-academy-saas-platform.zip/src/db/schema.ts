import { pgTable, uuid, text, integer, numeric, timestamp, varchar, pgEnum } from "drizzle-orm/pg-core";

// Enums
export const categoryEnum = pgEnum("category", [
  "Sub-7",
  "Sub-9",
  "Sub-10",
  "Sub-12",
  "Sub-13",
  "Sub-15",
  "Sub-17",
  "Sub-20",
  "Libre",
]);

export const attendanceStatusEnum = pgEnum("attendance_status", [
  "presente",
  "ausente",
  "excusa",
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "al_dia",
  "pago_pendiente",
  "vencido",
]);

export const messageStatusEnum = pgEnum("message_status", [
  "pendiente",
  "enviado",
  "fallido",
]);

// Guardians (Parents)
export const guardians = pgTable("guardians", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 200 }),
  paymentStatus: paymentStatusEnum("payment_status").default("al_dia"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Players (Students)
export const players = pgTable("players", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  age: integer("age").notNull(),
  category: categoryEnum("category").notNull(),
  weight: numeric("weight", { precision: 5, scale: 2 }),
  height: numeric("height", { precision: 5, scale: 2 }),
  bmi: numeric("bmi", { precision: 4, scale: 1 }),
  guardianId: uuid("guardian_id").references(() => guardians.id),
  position: varchar("position", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Attendance
export const attendance = pgTable("attendance", {
  id: uuid("id").defaultRandom().primaryKey(),
  playerId: uuid("player_id").references(() => players.id).notNull(),
  date: timestamp("date").notNull(),
  status: attendanceStatusEnum("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Training Plans
export const trainingPlans = pgTable("training_plans", {
  id: uuid("id").defaultRandom().primaryKey(),
  date: timestamp("date").notNull(),
  category: categoryEnum("category"),
  planText: text("plan_text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Messages
export const messages = pgTable("messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  guardianId: uuid("guardian_id").references(() => guardians.id).notNull(),
  messageText: text("message_text").notNull(),
  sentVia: varchar("sent_via", { length: 50 }).default("whatsapp"),
  status: messageStatusEnum("status").default("pendiente"),
  sentAt: timestamp("sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
