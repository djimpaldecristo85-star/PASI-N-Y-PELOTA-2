import { db } from "@/db";
import { messages, guardians } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const result = await db.select().from(messages).orderBy(messages.createdAt);

    // Enrich with guardian info
    const enriched = await Promise.all(
      result.map(async (msg) => {
        const guardian = await db.select({ name: guardians.name, phone: guardians.phone }).from(guardians).where(eq(guardians.id, msg.guardianId)).limit(1);
        return { ...msg, guardianName: guardian[0]?.name || "Desconocido", guardianPhone: guardian[0]?.phone || "" };
      })
    );

    return NextResponse.json(enriched);
  } catch (error) {
    console.error("Error fetching messages:", error);
    return NextResponse.json({ error: "Failed to fetch messages" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Support bulk insert for batch messaging
    if (Array.isArray(body)) {
      const result = await db.insert(messages).values(body).returning();
      return NextResponse.json(result, { status: 201 });
    }

    const { guardianId, messageText, sentVia } = body;

    const result = await db.insert(messages).values({
      guardianId,
      messageText,
      sentVia: sentVia || "whatsapp",
      status: "pendiente",
    }).returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating message:", error);
    return NextResponse.json({ error: "Failed to create message" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status } = body;

    const result = await db.update(messages).set({
      status,
      sentAt: status === "enviado" ? new Date() : undefined,
    }).where(eq(messages.id, id)).returning();

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating message:", error);
    return NextResponse.json({ error: "Failed to update message" }, { status: 500 });
  }
}
