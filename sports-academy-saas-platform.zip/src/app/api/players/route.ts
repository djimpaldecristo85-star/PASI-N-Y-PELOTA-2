import { db } from "@/db";
import { players, guardians } from "@/db/schema";
import { eq, like, or, and } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const category = searchParams.get("category");
    const search = searchParams.get("search");

    let result;
    if (category) {
      result = await db.select().from(players).where(eq(players.category, category as typeof players.$inferInsert.category));
    } else if (search) {
      result = await db.select().from(players).where(like(players.name, `%${search}%`));
    } else {
      result = await db.select().from(players);
    }

    // Get guardians for each player
    const playersWithGuardians = await Promise.all(
      result.map(async (player) => {
        if (player.guardianId) {
          const guardian = await db.select().from(guardians).where(eq(guardians.id, player.guardianId)).limit(1);
          return { ...player, guardian: guardian[0] || null };
        }
        return { ...player, guardian: null };
      })
    );

    return NextResponse.json(playersWithGuardians);
  } catch (error) {
    console.error("Error fetching players:", error);
    return NextResponse.json({ error: "Failed to fetch players" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, age, category, weight, height, bmi, guardianId, position } = body;

    // Calculate BMI if weight and height provided
    let calculatedBmi = bmi;
    if (weight && height && !bmi) {
      const heightM = parseFloat(height) / 100;
      if (heightM > 0) {
        calculatedBmi = (parseFloat(weight) / (heightM * heightM)).toFixed(1);
      }
    }

    const result = await db.insert(players).values({
      name,
      age,
      category,
      weight: weight || null,
      height: height || null,
      bmi: calculatedBmi || null,
      guardianId: guardianId || null,
      position: position || null,
    }).returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating player:", error);
    return NextResponse.json({ error: "Failed to create player" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, age, category, weight, height, bmi, guardianId, position } = body;

    // Calculate BMI if weight and height provided
    let calculatedBmi = bmi;
    if (weight && height) {
      const heightM = parseFloat(height) / 100;
      if (heightM > 0) {
        calculatedBmi = (parseFloat(weight) / (heightM * heightM)).toFixed(1);
      }
    }

    const result = await db.update(players).set({
      name,
      age,
      category,
      weight: weight || null,
      height: height || null,
      bmi: calculatedBmi || null,
      guardianId: guardianId || null,
      position: position || null,
    }).where(eq(players.id, id)).returning();

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating player:", error);
    return NextResponse.json({ error: "Failed to update player" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Player ID required" }, { status: 400 });
    }

    await db.delete(players).where(eq(players.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting player:", error);
    return NextResponse.json({ error: "Failed to delete player" }, { status: 500 });
  }
}
