import { db } from "@/db";
import { attendance, players, guardians, messages } from "@/db/schema";
import { eq, and, gte, lte, count, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const from = searchParams.get("from");
    const to = searchParams.get("to");

    // Default to current month if no dates provided
    const now = new Date();
    const fromDate = from ? new Date(from) : new Date(now.getFullYear(), now.getMonth(), 1);
    const toDate = to ? new Date(to) : new Date(now.getFullYear(), now.getMonth() + 1, 0);
    fromDate.setHours(0, 0, 0, 0);
    toDate.setHours(23, 59, 59, 999);

    // Total players
    const allPlayers = await db.select().from(players);
    const totalPlayers = allPlayers.length;

    // Attendance in period
    const attendanceRecords = await db.select().from(attendance).where(
      and(
        gte(attendance.date, fromDate),
        lte(attendance.date, toDate)
      )
    );

    const totalAttendance = attendanceRecords.length;
    const presentCount = attendanceRecords.filter(a => a.status === "presente").length;
    const absentCount = attendanceRecords.filter(a => a.status === "ausente").length;
    const excusedCount = attendanceRecords.filter(a => a.status === "excusa").length;
    const attendancePercentage = totalAttendance > 0 ? ((presentCount / totalAttendance) * 100).toFixed(1) : "0";

    // Guardians payment status
    const allGuardians = await db.select().from(guardians);
    const paidCount = allGuardians.filter(g => g.paymentStatus === "al_dia").length;
    const pendingCount = allGuardians.filter(g => g.paymentStatus === "pago_pendiente").length;
    const overdueCount = allGuardians.filter(g => g.paymentStatus === "vencido").length;

    // Messages sent
    const messageRecords = await db.select().from(messages).where(
      and(
        gte(messages.createdAt, fromDate),
        lte(messages.createdAt, toDate)
      )
    );
    const messagesSent = messageRecords.filter(m => m.status === "enviado").length;
    const messagesPending = messageRecords.filter(m => m.status === "pendiente").length;

    // Players by category
    const categoryCounts: Record<string, number> = {};
    allPlayers.forEach(p => {
      categoryCounts[p.category] = (categoryCounts[p.category] || 0) + 1;
    });

    // Attendance by category
    const attendanceByCategory: Record<string, { total: number; present: number }> = {};
    for (const record of attendanceRecords) {
      const player = allPlayers.find(p => p.id === record.playerId);
      if (player) {
        if (!attendanceByCategory[player.category]) {
          attendanceByCategory[player.category] = { total: 0, present: 0 };
        }
        attendanceByCategory[player.category].total++;
        if (record.status === "presente") {
          attendanceByCategory[player.category].present++;
        }
      }
    }

    // Training sessions count (unique dates with attendance)
    const uniqueDates = new Set(attendanceRecords.map(a => new Date(a.date).toDateString()));
    const trainingSessions = uniqueDates.size;

    return NextResponse.json({
      period: { from: fromDate.toISOString(), to: toDate.toISOString() },
      players: {
        total: totalPlayers,
        byCategory: categoryCounts,
      },
      attendance: {
        total: totalAttendance,
        present: presentCount,
        absent: absentCount,
        excused: excusedCount,
        percentage: attendancePercentage,
        byCategory: attendanceByCategory,
        trainingSessions,
      },
      payments: {
        paid: paidCount,
        pending: pendingCount,
        overdue: overdueCount,
        total: allGuardians.length,
      },
      messaging: {
        sent: messagesSent,
        pending: messagesPending,
        total: messageRecords.length,
      },
    });
  } catch (error) {
    console.error("Error generating report:", error);
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 });
  }
}
