import { db } from "@/db";
import { attendance, players } from "@/db/schema";
import { eq, and, gte, lte } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const date = searchParams.get("date");
    const playerId = searchParams.get("playerId");
    const from = searchParams.get("from");
    const to = searchParams.get("to");

    let conditions = [];

    if (date) {
      const dayStart = new Date(date);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(date);
      dayEnd.setHours(23, 59, 59, 999);
      conditions.push(gte(attendance.date, dayStart));
      conditions.push(lte(attendance.date, dayEnd));
    }

    if (from && to) {
      const fromDate = new Date(from);
      fromDate.setHours(0, 0, 0, 0);
      const toDate = new Date(to);
      toDate.setHours(23, 59, 59, 999);
      conditions.push(gte(attendance.date, fromDate));
      conditions.push(lte(attendance.date, toDate));
    }

    if (playerId) {
      conditions.push(eq(attendance.playerId, playerId));
    }

    let result;
    if (conditions.length > 0) {
      result = await db.select().from(attendance).where(and(...conditions)).orderBy(attendance.date);
    } else {
      result = await db.select().from(attendance).orderBy(attendance.date);
    }

    // Enrich with player names
    const enriched = await Promise.all(
      result.map(async (record) => {
        const player = await db.select({ name: players.name, category: players.category }).from(players).where(eq(players.id, record.playerId)).limit(1);
        return { ...record, playerName: player[0]?.name || "Desconocido", playerCategory: player[0]?.category || "" };
      })
    );

    return NextResponse.json(enriched);
  } catch (error) {
    console.error("Error fetching attendance:", error);
    return NextResponse.json({ error: "Failed to fetch attendance" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Support bulk insert
    if (Array.isArray(body)) {
      const result = await db.insert(attendance).values(body).returning();
      return NextResponse.json(result, { status: 201 });
    }

    const { playerId, date, status } = body;
    const attendanceDate = new Date(date);

    // Check if record exists for this player and date
    const dayStart = new Date(attendanceDate);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(attendanceDate);
    dayEnd.setHours(23, 59, 59, 999);

    const existing = await db.select().from(attendance).where(
      and(
        eq(attendance.playerId, playerId),
        gte(attendance.date, dayStart),
        lte(attendance.date, dayEnd)
      )
    ).limit(1);

    if (existing.length > 0) {
      // Update existing
      const result = await db.update(attendance).set({ status }).where(eq(attendance.id, existing[0].id)).returning();
      return NextResponse.json(result[0]);
    }

    // Create new
    const result = await db.insert(attendance).values({
      playerId,
      date: attendanceDate,
      status,
    }).returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating attendance:", error);
    return NextResponse.json({ error: "Failed to create attendance" }, { status: 500 });
  }
}
