import { db } from "@/db";
import { guardians } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const result = await db.select().from(guardians).orderBy(guardians.name);
    return NextResponse.json(result);
  } catch (error) {
    console.error("Error fetching guardians:", error);
    return NextResponse.json({ error: "Failed to fetch guardians" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, email, paymentStatus } = body;

    const result = await db.insert(guardians).values({
      name,
      phone,
      email: email || null,
      paymentStatus: paymentStatus || "al_dia",
    }).returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating guardian:", error);
    return NextResponse.json({ error: "Failed to create guardian" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, phone, email, paymentStatus } = body;

    const result = await db.update(guardians).set({
      name,
      phone,
      email: email || null,
      paymentStatus: paymentStatus || "al_dia",
    }).where(eq(guardians.id, id)).returning();

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating guardian:", error);
    return NextResponse.json({ error: "Failed to update guardian" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Guardian ID required" }, { status: 400 });
    }

    await db.delete(guardians).where(eq(guardians.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting guardian:", error);
    return NextResponse.json({ error: "Failed to delete guardian" }, { status: 500 });
  }
}
