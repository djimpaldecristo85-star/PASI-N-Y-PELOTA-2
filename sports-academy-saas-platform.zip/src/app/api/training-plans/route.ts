import { db } from "@/db";
import { trainingPlans } from "@/db/schema";
import { eq, and, gte, lte } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const date = searchParams.get("date");
    const category = searchParams.get("category");

    let conditions = [];

    if (date) {
      const dayStart = new Date(date);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(date);
      dayEnd.setHours(23, 59, 59, 999);
      conditions.push(gte(trainingPlans.date, dayStart));
      conditions.push(lte(trainingPlans.date, dayEnd));
    }

    if (category) {
      conditions.push(eq(trainingPlans.category, category as "Sub-7" | "Sub-9" | "Sub-10" | "Sub-12" | "Sub-13" | "Sub-15" | "Sub-17" | "Sub-20" | "Libre"));
    }

    let result;
    if (conditions.length > 0) {
      result = await db.select().from(trainingPlans).where(and(...conditions)).orderBy(trainingPlans.date);
    } else {
      result = await db.select().from(trainingPlans).orderBy(trainingPlans.date);
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error("Error fetching training plans:", error);
    return NextResponse.json({ error: "Failed to fetch training plans" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { date, category, planText } = body;

    const result = await db.insert(trainingPlans).values({
      date: new Date(date),
      category: category || null,
      planText,
    }).returning();

    return NextResponse.json(result[0], { status: 201 });
  } catch (error) {
    console.error("Error creating training plan:", error);
    return NextResponse.json({ error: "Failed to create training plan" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, date, category, planText } = body;

    const result = await db.update(trainingPlans).set({
      date: new Date(date),
      category: category || null,
      planText,
    }).where(eq(trainingPlans.id, id)).returning();

    return NextResponse.json(result[0]);
  } catch (error) {
    console.error("Error updating training plan:", error);
    return NextResponse.json({ error: "Failed to update training plan" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Training plan ID required" }, { status: 400 });
    }

    await db.delete(trainingPlans).where(eq(trainingPlans.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting training plan:", error);
    return NextResponse.json({ error: "Failed to delete training plan" }, { status: 500 });
  }
}
