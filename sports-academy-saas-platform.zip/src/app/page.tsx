import { Suspense } from "react";
import AppShell from "@/components/AppShell";

export default function Home() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-neon-green border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-neon-green font-semibold text-lg">Cargando sistema...</p>
        </div>
      </div>
    }>
      <AppShell />
    </Suspense>
  );
}
