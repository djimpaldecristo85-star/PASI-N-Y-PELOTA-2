import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pelota y Pasión | Academia Deportiva",
  description: "Sistema de gestión integral para academias deportivas - Control de jugadores, asistencia, mensajería y reportes.",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0D1117",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" className="dark">
      <body className="bg-dark-bg text-white antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
