"use client";

import { useState, useCallback } from "react";
import Header from "./Header";
import Module1Players from "./Module1Players";
import Module2Attendance from "./Module2Attendance";
import Module3Messaging from "./Module3Messaging";
import Module4Reports from "./Module4Reports";
import {
  Users,
  ClipboardCheck,
  MessageSquare,
  BarChart3,
} from "lucide-react";

const tabs = [
  { id: "players", label: "Jugadores", icon: Users },
  { id: "attendance", label: "Asistencia", icon: ClipboardCheck },
  { id: "messaging", label: "Mensajería", icon: MessageSquare },
  { id: "reports", label: "Reportes", icon: BarChart3 },
] as const;

type TabId = (typeof tabs)[number]["id"];

export default function AppShell() {
  const [activeTab, setActiveTab] = useState<TabId>("players");
  const [assistantStatus, setAssistantStatus] = useState<
    "online" | "processing" | "offline"
  >("online");

  const handleAssistantStatus = useCallback(
    (status: "online" | "processing" | "offline") => {
      setAssistantStatus(status);
    },
    []
  );

  return (
    <div className="min-h-screen bg-dark-bg flex flex-col">
      <Header assistantStatus={assistantStatus} />

      {/* Main Content */}
      <main className="flex-1 pb-20 lg:pb-4 lg:ml-56 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 py-4">
          {activeTab === "players" && <Module1Players />}
          {activeTab === "attendance" && <Module2Attendance />}
          {activeTab === "messaging" && (
            <Module3Messaging onAssistantStatus={handleAssistantStatus} />
          )}
          {activeTab === "reports" && <Module4Reports />}
        </div>
      </main>

      {/* Bottom Navigation - Mobile */}
      <nav className="fixed bottom-0 left-0 right-0 bg-dark-surface border-t border-dark-border z-50 lg:hidden">
        <div className="flex items-center justify-around">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`touch-btn flex flex-col items-center justify-center py-2 px-3 min-w-0 flex-1 transition-smooth ${
                  isActive
                    ? "text-neon-green"
                    : "text-gray-500 hover:text-gray-300"
                }`}
              >
                <Icon
                  className={`w-5 h-5 mb-1 ${isActive ? "drop-shadow-[0_0_8px_rgba(0,255,102,0.5)]" : ""}`}
                />
                <span className="text-[10px] font-medium truncate">
                  {tab.label}
                </span>
                {isActive && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-neon-green rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Sidebar Navigation - Desktop */}
      <aside className="hidden lg:block fixed left-0 top-16 bottom-0 w-56 bg-dark-surface border-r border-dark-border overflow-y-auto">
        <div className="py-4 px-3 space-y-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`touch-btn w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-smooth text-left ${
                  isActive
                    ? "bg-neon-green/10 text-neon-green border border-neon-green/20"
                    : "text-gray-400 hover:bg-dark-hover hover:text-gray-200 border border-transparent"
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="font-medium text-sm">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </aside>

    </div>
  );
}
