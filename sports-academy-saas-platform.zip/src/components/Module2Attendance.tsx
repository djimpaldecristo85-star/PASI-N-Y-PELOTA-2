"use client";

import { useState, useEffect, useCallback } from "react";
import {
  ClipboardCheck,
  Check,
  X,
  AlertCircle,
  Save,
  Calendar,
  FileText,
  ChevronLeft,
  ChevronRight,
  History,
  Plus,
} from "lucide-react";
import { format, startOfDay, addDays, subDays } from "date-fns";
import { es } from "date-fns/locale";

const CATEGORIES = [
  "Sub-7", "Sub-9", "Sub-10", "Sub-12", "Sub-13", "Sub-15", "Sub-17", "Sub-20", "Libre",
] as const;

type Category = (typeof CATEGORIES)[number];

interface Player {
  id: string;
  name: string;
  age: number;
  category: Category;
}

interface AttendanceRecord {
  id: string;
  playerId: string;
  date: string;
  status: "presente" | "ausente" | "excusa";
  playerName?: string;
  playerCategory?: string;
}

interface TrainingPlan {
  id: string;
  date: string;
  category: Category | null;
  planText: string;
}

export default function Module2Attendance() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [attendance, setAttendance] = useState<Map<string, "presente" | "ausente" | "excusa">>(new Map());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [filterCat, setFilterCat] = useState<string>("");
  const [showHistory, setShowHistory] = useState(false);
  const [historyRecords, setHistoryRecords] = useState<AttendanceRecord[]>([]);

  // Training plan state
  const [trainingPlans, setTrainingPlans] = useState<TrainingPlan[]>([]);
  const [showPlanForm, setShowPlanForm] = useState(false);
  const [planText, setPlanText] = useState("");
  const [planCategory, setPlanCategory] = useState<string>("");
  const [editingPlan, setEditingPlan] = useState<TrainingPlan | null>(null);

  const fetchPlayers = useCallback(async () => {
    try {
      const res = await fetch("/api/players");
      const data = await res.json();
      setPlayers(data);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const fetchAttendance = useCallback(async () => {
    try {
      const dateStr = format(selectedDate, "yyyy-MM-dd");
      const res = await fetch(`/api/attendance?date=${dateStr}`);
      const data = await res.json();
      const map = new Map<string, "presente" | "ausente" | "excusa">();
      data.forEach((r: AttendanceRecord) => {
        map.set(r.playerId, r.status);
      });
      setAttendance(map);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [selectedDate]);

  const fetchTrainingPlans = useCallback(async () => {
    try {
      const dateStr = format(selectedDate, "yyyy-MM-dd");
      const res = await fetch(`/api/training-plans?date=${dateStr}`);
      const data = await res.json();
      setTrainingPlans(data);
    } catch (err) {
      console.error(err);
    }
  }, [selectedDate]);

  useEffect(() => {
    fetchPlayers();
  }, [fetchPlayers]);

  useEffect(() => {
    fetchAttendance();
    fetchTrainingPlans();
  }, [fetchAttendance, fetchTrainingPlans]);

  const handleAttendance = (playerId: string, status: "presente" | "ausente" | "excusa") => {
    setAttendance((prev) => {
      const next = new Map(prev);
      // Toggle: if same status, remove; else set
      if (next.get(playerId) === status) {
        next.delete(playerId);
      } else {
        next.set(playerId, status);
      }
      return next;
    });
  };

  const saveAttendance = async () => {
    setSaving(true);
    try {
      const promises = Array.from(attendance.entries()).map(([playerId, status]) =>
        fetch("/api/attendance", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            playerId,
            date: format(selectedDate, "yyyy-MM-dd"),
            status,
          }),
        })
      );
      await Promise.all(promises);
      fetchAttendance();
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const fetchHistory = async (range: "week" | "month") => {
    try {
      const to = format(selectedDate, "yyyy-MM-dd");
      const from = format(
        range === "week" ? subDays(selectedDate, 7) : subDays(selectedDate, 30),
        "yyyy-MM-dd"
      );
      const res = await fetch(`/api/attendance?from=${from}&to=${to}`);
      const data = await res.json();
      setHistoryRecords(data);
      setShowHistory(true);
    } catch (err) {
      console.error(err);
    }
  };

  const saveTrainingPlan = async () => {
    if (!planText) return;
    try {
      const body = {
        date: format(selectedDate, "yyyy-MM-dd"),
        category: planCategory || null,
        planText,
      };
      if (editingPlan) {
        await fetch("/api/training-plans", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...body, id: editingPlan.id }),
        });
      } else {
        await fetch("/api/training-plans", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      }
      setPlanText("");
      setPlanCategory("");
      setEditingPlan(null);
      setShowPlanForm(false);
      fetchTrainingPlans();
    } catch (err) {
      console.error(err);
    }
  };

  const deletePlan = async (id: string) => {
    if (!confirm("¿Eliminar este plan?")) return;
    try {
      await fetch(`/api/training-plans?id=${id}`, { method: "DELETE" });
      fetchTrainingPlans();
    } catch (err) {
      console.error(err);
    }
  };

  const filteredPlayers = filterCat
    ? players.filter((p) => p.category === filterCat)
    : players;

  const presentCount = Array.from(attendance.values()).filter((s) => s === "presente").length;
  const absentCount = Array.from(attendance.values()).filter((s) => s === "ausente").length;
  const excusedCount = Array.from(attendance.values()).filter((s) => s === "excusa").length;

  return (
    <div className="space-y-4">
      {/* Module Title */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-athletic-blue/20 flex items-center justify-center">
          <ClipboardCheck className="w-4 h-4 text-athletic-blue" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Asistencia y Plan del Día</h2>
          <p className="text-xs text-gray-500">Registro diario de asistencia y entrenamiento</p>
        </div>
      </div>

      {/* Date Navigation */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-3">
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={() => setSelectedDate((d) => subDays(d, 1))}
            className="touch-btn p-2 rounded-lg hover:bg-dark-hover text-gray-400 hover:text-white"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <p className="text-sm font-semibold text-white">
              {format(selectedDate, "EEEE d 'de' MMMM, yyyy", { locale: es })}
            </p>
            <p className="text-xs text-gray-500">
              {format(selectedDate, "yyyy-MM-dd")}
            </p>
          </div>
          <button
            onClick={() => setSelectedDate((d) => addDays(d, 1))}
            className="touch-btn p-2 rounded-lg hover:bg-dark-hover text-gray-400 hover:text-white"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-2 mt-3">
          <div className="bg-neon-green/10 rounded-lg px-3 py-2 text-center">
            <p className="text-lg font-bold text-neon-green">{presentCount}</p>
            <p className="text-[10px] text-neon-green/70">Presentes</p>
          </div>
          <div className="bg-red-500/10 rounded-lg px-3 py-2 text-center">
            <p className="text-lg font-bold text-red-400">{absentCount}</p>
            <p className="text-[10px] text-red-400/70">Ausentes</p>
          </div>
          <div className="bg-gold/10 rounded-lg px-3 py-2 text-center">
            <p className="text-lg font-bold text-gold">{excusedCount}</p>
            <p className="text-[10px] text-gold/70">Excusa</p>
          </div>
        </div>
      </div>

      {/* Category Filter + Actions */}
      <div className="flex flex-wrap gap-2">
        <select
          value={filterCat}
          onChange={(e) => setFilterCat(e.target.value)}
          className="bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
        >
          <option value="">Todas las categorías</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <button
          onClick={() => fetchHistory("week")}
          className="touch-btn bg-dark-surface border border-dark-border text-gray-400 px-3 py-2 rounded-lg text-xs flex items-center gap-1.5 hover:text-white hover:border-gray-500"
        >
          <History className="w-3.5 h-3.5" /> Semana
        </button>
        <button
          onClick={() => fetchHistory("month")}
          className="touch-btn bg-dark-surface border border-dark-border text-gray-400 px-3 py-2 rounded-lg text-xs flex items-center gap-1.5 hover:text-white hover:border-gray-500"
        >
          <History className="w-3.5 h-3.5" /> Mes
        </button>
        <button
          onClick={saveAttendance}
          disabled={saving || attendance.size === 0}
          className="touch-btn bg-neon-green text-dark-bg font-semibold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 disabled:opacity-50 ml-auto"
        >
          <Save className="w-3.5 h-3.5" /> {saving ? "Guardando..." : "Guardar"}
        </button>
      </div>

      {/* Attendance List */}
      {loading ? (
        <div className="text-center py-8">
          <div className="w-8 h-8 border-2 border-athletic-blue border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      ) : filteredPlayers.length === 0 ? (
        <div className="text-center py-8 bg-dark-surface rounded-xl border border-dark-border">
          <ClipboardCheck className="w-10 h-10 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 text-sm">No hay jugadores registrados</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredPlayers.map((player) => {
            const status = attendance.get(player.id);
            return (
              <div
                key={player.id}
                className="bg-dark-surface rounded-xl border border-dark-border p-3 flex items-center gap-3"
              >
                {/* Player Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{player.name}</p>
                  <p className="text-xs text-gray-500">
                    {player.category} • {player.age} años
                  </p>
                </div>

                {/* Attendance Buttons */}
                <div className="flex gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => handleAttendance(player.id, "presente")}
                    className={`touch-btn w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                      status === "presente"
                        ? "bg-neon-green text-dark-bg shadow-[0_0_12px_rgba(0,255,102,0.3)]"
                        : "bg-dark-bg border border-dark-border text-gray-500 hover:border-neon-green/50"
                    }`}
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleAttendance(player.id, "ausente")}
                    className={`touch-btn w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                      status === "ausente"
                        ? "bg-red-500 text-white shadow-[0_0_12px_rgba(255,0,0,0.3)]"
                        : "bg-dark-bg border border-dark-border text-gray-500 hover:border-red-500/50"
                    }`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleAttendance(player.id, "excusa")}
                    className={`touch-btn w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                      status === "excusa"
                        ? "bg-gold text-dark-bg shadow-[0_0_12px_rgba(255,215,0,0.3)]"
                        : "bg-dark-bg border border-dark-border text-gray-500 hover:border-gold/50"
                    }`}
                  >
                    <AlertCircle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Training Plans Section */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-4 glow-blue">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-athletic-blue flex items-center gap-2">
            <FileText className="w-4 h-4" /> Programa de Entrenamiento
          </h3>
          <button
            onClick={() => { setEditingPlan(null); setPlanText(""); setPlanCategory(""); setShowPlanForm(true); }}
            className="touch-btn bg-athletic-blue/20 text-athletic-blue px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 hover:bg-athletic-blue/30"
          >
            <Plus className="w-3 h-3" /> Nuevo Plan
          </button>
        </div>

        {/* Existing Plans */}
        {trainingPlans.length > 0 ? (
          <div className="space-y-2 mb-3">
            {trainingPlans.map((plan) => (
              <div key={plan.id} className="bg-dark-bg rounded-lg p-3 border border-dark-border">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    {plan.category && (
                      <span className="text-[10px] bg-athletic-blue/10 text-athletic-blue px-2 py-0.5 rounded-full mb-1 inline-block">
                        {plan.category}
                      </span>
                    )}
                    <p className="text-sm text-gray-300 whitespace-pre-wrap mt-1">{plan.planText}</p>
                  </div>
                  <div className="flex gap-1 ml-2 flex-shrink-0">
                    <button
                      onClick={() => {
                        setEditingPlan(plan);
                        setPlanText(plan.planText);
                        setPlanCategory(plan.category || "");
                        setShowPlanForm(true);
                      }}
                      className="p-1 text-gray-500 hover:text-athletic-blue"
                    >
                      <FileText className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => deletePlan(plan.id)}
                      className="p-1 text-gray-500 hover:text-red-400"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-gray-500 mb-3">No hay planes registrados para este día</p>
        )}

        {/* Plan Form */}
        {showPlanForm && (
          <div className="bg-dark-bg rounded-lg p-3 border border-dark-border space-y-2">
            <select
              value={planCategory}
              onChange={(e) => setPlanCategory(e.target.value)}
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
            >
              <option value="">General (todas las categorías)</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <textarea
              value={planText}
              onChange={(e) => setPlanText(e.target.value)}
              placeholder="Ej: Fuerza explosiva (20 min) + Técnica individual (30 min) + Partido reducido (25 min)"
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-athletic-blue focus:outline-none min-h-[80px] resize-y"
              rows={3}
            />
            <div className="flex gap-2">
              <button
                onClick={saveTrainingPlan}
                disabled={!planText}
                className="touch-btn flex-1 bg-athletic-blue text-white font-medium py-2 rounded-lg text-sm disabled:opacity-50"
              >
                {editingPlan ? "Actualizar" : "Guardar Plan"}
              </button>
              <button
                onClick={() => { setShowPlanForm(false); setEditingPlan(null); }}
                className="touch-btn px-4 py-2 rounded-lg text-sm text-gray-400 hover:text-white border border-dark-border"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>

      {/* History Modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-dark-surface rounded-2xl border border-dark-border w-full max-w-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-dark-border">
              <h3 className="font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-athletic-blue" /> Historial de Asistencia
              </h3>
              <button onClick={() => setShowHistory(false)} className="text-gray-500 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">
              {historyRecords.length === 0 ? (
                <p className="text-gray-500 text-sm text-center py-8">No hay registros en este período</p>
              ) : (
                <div className="space-y-1">
                  {historyRecords.map((r) => (
                    <div key={r.id} className="flex items-center gap-3 py-2 border-b border-dark-border/50 last:border-0">
                      <span className="text-xs text-gray-500 w-20 flex-shrink-0">
                        {format(new Date(r.date), "dd/MM")}
                      </span>
                      <span className="text-sm text-white flex-1 truncate">{r.playerName}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        r.status === "presente" ? "bg-neon-green/10 text-neon-green" :
                        r.status === "ausente" ? "bg-red-500/10 text-red-400" :
                        "bg-gold/10 text-gold"
                      }`}>
                        {r.status === "presente" ? "✓ Presente" : r.status === "ausente" ? "✗ Ausente" : "! Excusa"}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
