"use client";

import { useState, useEffect, useCallback } from "react";
import {
  MessageSquare,
  Phone,
  Send,
  UserPlus,
  Edit3,
  X,
  Save,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Bot,
  ExternalLink,
  DollarSign,
  Users,
  Bell,
  Shield,
} from "lucide-react";

interface Guardian {
  id: string;
  name: string;
  phone: string;
  email?: string;
  paymentStatus: "al_dia" | "pago_pendiente" | "vencido";
}

interface Message {
  id: string;
  guardianId: string;
  messageText: string;
  sentVia: string;
  status: "pendiente" | "enviado" | "fallido";
  guardianName?: string;
  guardianPhone?: string;
  createdAt: string;
  sentAt?: string;
}

interface Player {
  id: string;
  name: string;
  guardianId: string | null;
  guardian?: { id: string; name: string; phone: string; paymentStatus: string } | null;
}

interface Module3Props {
  onAssistantStatus: (status: "online" | "processing" | "offline") => void;
}

const ASSISTANT_COMMANDS = [
  {
    id: "remind_payment",
    label: "Recordatorio de pago mensual",
    description: "Enviar recordatorio de pago a los alumnos con cuota vencida",
    icon: DollarSign,
    color: "text-gold",
    bgColor: "bg-gold/10",
  },
  {
    id: "notify_absences",
    label: "Notificar ausencias del día",
    description: "Informar a los acudientes sobre las ausencias de hoy",
    icon: Bell,
    color: "text-red-400",
    bgColor: "bg-red-500/10",
  },
  {
    id: "weekly_summary",
    label: "Resumen semanal",
    description: "Enviar resumen de asistencia semanal a todos los acudientes",
    icon: Shield,
    color: "text-athletic-blue",
    bgColor: "bg-athletic-blue/10",
  },
  {
    id: "custom_message",
    label: "Mensaje personalizado",
    description: "Redactar y enviar un mensaje libre a los acudientes",
    icon: MessageSquare,
    color: "text-neon-green",
    bgColor: "bg-neon-green/10",
  },
];

export default function Module3Messaging({ onAssistantStatus }: Module3Props) {
  const [guardians, setGuardians] = useState<Guardian[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [showGuardianForm, setShowGuardianForm] = useState(false);
  const [editingGuardian, setEditingGuardian] = useState<Guardian | null>(null);

  // Guardian form
  const [gName, setGName] = useState("");
  const [gPhone, setGPhone] = useState("");
  const [gEmail, setGEmail] = useState("");
  const [gPayment, setGPayment] = useState<string>("al_dia");

  // Custom message form
  const [showCustomMsg, setShowCustomMsg] = useState(false);
  const [customMsgText, setCustomMsgText] = useState("");
  const [customMsgTargets, setCustomMsgTargets] = useState<string[]>([]);

  // Assistant processing
  const [processing, setProcessing] = useState(false);
  const [lastResult, setLastResult] = useState<string>("");

  const fetchGuardians = useCallback(async () => {
    try {
      const res = await fetch("/api/guardians");
      setGuardians(await res.json());
    } catch (err) {
      console.error(err);
    }
  }, []);

  const fetchMessages = useCallback(async () => {
    try {
      const res = await fetch("/api/messages");
      setMessages(await res.json());
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchPlayers = useCallback(async () => {
    try {
      const res = await fetch("/api/players");
      setPlayers(await res.json());
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    fetchGuardians();
    fetchMessages();
    fetchPlayers();
  }, [fetchGuardians, fetchMessages, fetchPlayers]);

  const resetGuardianForm = () => {
    setGName("");
    setGPhone("");
    setGEmail("");
    setGPayment("al_dia");
    setEditingGuardian(null);
    setShowGuardianForm(false);
  };

  const saveGuardian = async () => {
    if (!gName || !gPhone) return;
    try {
      if (editingGuardian) {
        await fetch("/api/guardians", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingGuardian.id, name: gName, phone: gPhone, email: gEmail, paymentStatus: gPayment }),
        });
      } else {
        await fetch("/api/guardians", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: gName, phone: gPhone, email: gEmail, paymentStatus: gPayment }),
        });
      }
      resetGuardianForm();
      fetchGuardians();
    } catch (err) {
      console.error(err);
    }
  };

  const editGuardian = (g: Guardian) => {
    setEditingGuardian(g);
    setGName(g.name);
    setGPhone(g.phone);
    setGEmail(g.email || "");
    setGPayment(g.paymentStatus);
    setShowGuardianForm(true);
  };

  const toggleCustomTarget = (id: string) => {
    setCustomMsgTargets((prev) =>
      prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
    );
  };

  const executeCommand = async (commandId: string) => {
    setProcessing(true);
    setLastResult("");
    onAssistantStatus("processing");

    try {
      if (commandId === "remind_payment") {
        const overdueGuardians = guardians.filter((g) => g.paymentStatus === "vencido" || g.paymentStatus === "pago_pendiente");
        if (overdueGuardians.length === 0) {
          setLastResult("✅ Todos los acudientes están al día con sus pagos.");
          return;
        }
        const messageText = "⚽ Pelota y Pasión - Recordatorio: Su cuota mensual se encuentra pendiente. Por favor, realice el pago a la brevedad. ¡Gracias!";
        const msgPromises = overdueGuardians.map((g) =>
          fetch("/api/messages", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ guardianId: g.id, messageText, sentVia: "whatsapp" }),
          })
        );
        await Promise.all(msgPromises);
        setLastResult(`📤 Recordatorios de pago enviados a ${overdueGuardians.length} acudiente(s).`);
      } else if (commandId === "notify_absences") {
        const today = new Date().toISOString().split("T")[0];
        const res = await fetch(`/api/attendance?date=${today}`);
        const attendanceData = await res.json();
        const absentRecords = attendanceData.filter((a: { status: string }) => a.status === "ausente");

        if (absentRecords.length === 0) {
          setLastResult("✅ No hay ausencias registradas hoy.");
          return;
        }

        const absentPlayerIds = absentRecords.map((a: { playerId: string }) => a.playerId);
        const absentPlayers = players.filter((p) => absentPlayerIds.includes(p.id));
        const guardiansToNotify = guardians.filter((g) =>
          absentPlayers.some((p) => p.guardianId === g.id)
        );

        if (guardiansToNotify.length === 0) {
          setLastResult("⚠️ Hay ausencias pero los jugadores no tienen acudiente asignado.");
          return;
        }

        const messageText = `⚽ Pelota y Pasión - Su hijo/a fue registrado/a como ausente en la sesión de hoy (${today}). Si tiene una justificación, por favor comuníquese con el profesor.`;
        const msgPromises = guardiansToNotify.map((g) =>
          fetch("/api/messages", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ guardianId: g.id, messageText, sentVia: "whatsapp" }),
          })
        );
        await Promise.all(msgPromises);
        setLastResult(`📤 Notificación de ausencia enviada a ${guardiansToNotify.length} acudiente(s).`);
      } else if (commandId === "weekly_summary") {
        if (guardians.length === 0) {
          setLastResult("⚠️ No hay acudientes registrados.");
          return;
        }
        const messageText = "⚽ Pelota y Pasión - Resumen Semanal: Revise el estado de asistencia de su hijo/a directamente en la plataforma. ¡Gracias por su apoyo!";
        const msgPromises = guardians.map((g) =>
          fetch("/api/messages", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ guardianId: g.id, messageText, sentVia: "whatsapp" }),
          })
        );
        await Promise.all(msgPromises);
        setLastResult(`📤 Resumen semanal enviado a ${guardians.length} acudiente(s).`);
      } else if (commandId === "custom_message") {
        setShowCustomMsg(true);
        setLastResult("");
        return;
      }

      fetchMessages();
    } catch (err) {
      console.error(err);
      setLastResult("❌ Error al procesar el comando del asistente.");
    } finally {
      setProcessing(false);
      onAssistantStatus("online");
    }
  };

  const sendCustomMessage = async () => {
    if (!customMsgText || customMsgTargets.length === 0) return;
    setProcessing(true);
    onAssistantStatus("processing");

    try {
      const msgPromises = customMsgTargets.map((gId) =>
        fetch("/api/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ guardianId: gId, messageText: `⚽ Pelota y Pasión - ${customMsgText}`, sentVia: "whatsapp" }),
        })
      );
      await Promise.all(msgPromises);
      setLastResult(`📤 Mensaje personalizado enviado a ${customMsgTargets.length} acudiente(s).`);
      setCustomMsgText("");
      setCustomMsgTargets([]);
      setShowCustomMsg(false);
      fetchMessages();
    } catch (err) {
      console.error(err);
      setLastResult("❌ Error al enviar el mensaje.");
    } finally {
      setProcessing(false);
      onAssistantStatus("online");
    }
  };

  const openWhatsApp = (phone: string, text: string) => {
    const cleanPhone = phone.replace(/[^0-9+]/g, "");
    const encodedText = encodeURIComponent(text);
    window.open(`https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`, "_blank");
  };

  const paymentStatusBadge = (status: string) => {
    if (status === "al_dia") return <span className="bg-neon-green/10 text-neon-green px-2 py-0.5 rounded-full text-[10px] font-medium">Al día</span>;
    if (status === "pago_pendiente") return <span className="bg-gold/10 text-gold px-2 py-0.5 rounded-full text-[10px] font-medium">Pendiente</span>;
    return <span className="bg-red-500/10 text-red-400 px-2 py-0.5 rounded-full text-[10px] font-medium">Vencido</span>;
  };

  return (
    <div className="space-y-4">
      {/* Module Title */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-gold/20 flex items-center justify-center">
          <Bot className="w-4 h-4 text-gold" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Asistente y Mensajería</h2>
          <p className="text-xs text-gray-500">Avisos, recordatorios y comunicación con padres</p>
        </div>
      </div>

      {/* Virtual Assistant Console */}
      <div className="bg-dark-surface rounded-xl border border-gold/30 p-4 glow-gold">
        <h3 className="text-sm font-semibold text-gold mb-3 flex items-center gap-2">
          <Bot className="w-4 h-4" /> Consola del Asistente Virtual
        </h3>
        <p className="text-xs text-gray-400 mb-3">
          Seleccione una acción para que el asistente la ejecute automáticamente:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {ASSISTANT_COMMANDS.map((cmd) => {
            const Icon = cmd.icon;
            return (
              <button
                key={cmd.id}
                onClick={() => executeCommand(cmd.id)}
                disabled={processing}
                className="touch-btn text-left bg-dark-bg border border-dark-border rounded-lg p-3 hover:border-gold/30 transition-all disabled:opacity-50 group"
              >
                <div className="flex items-center gap-2 mb-1">
                  <div className={`w-7 h-7 rounded-lg ${cmd.bgColor} flex items-center justify-center`}>
                    <Icon className={`w-3.5 h-3.5 ${cmd.color}`} />
                  </div>
                  <span className="text-sm font-medium text-white group-hover:text-gold transition-colors">
                    {cmd.label}
                  </span>
                </div>
                <p className="text-[10px] text-gray-500 ml-9">{cmd.description}</p>
              </button>
            );
          })}
        </div>

        {/* Processing indicator */}
        {processing && (
          <div className="mt-3 flex items-center gap-2 text-gold text-sm">
            <Loader2 className="w-4 h-4 animate-spin" />
            Procesando comando...
          </div>
        )}

        {/* Result */}
        {lastResult && (
          <div className="mt-3 bg-dark-bg rounded-lg p-3 border border-dark-border text-sm text-gray-300">
            {lastResult}
          </div>
        )}
      </div>

      {/* Custom Message Modal */}
      {showCustomMsg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-dark-surface rounded-2xl border border-dark-border w-full max-w-lg max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-dark-border">
              <h3 className="font-bold text-white">Mensaje Personalizado</h3>
              <button onClick={() => setShowCustomMsg(false)} className="text-gray-500 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Mensaje</label>
                <textarea
                  value={customMsgText}
                  onChange={(e) => setCustomMsgText(e.target.value)}
                  placeholder="Escriba su mensaje aquí..."
                  className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-neon-green focus:outline-none min-h-[80px] resize-y"
                  rows={3}
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-2 block">
                  Destinatarios ({customMsgTargets.length} seleccionados)
                </label>
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {guardians.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => toggleCustomTarget(g.id)}
                      className={`w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all ${
                        customMsgTargets.includes(g.id)
                          ? "bg-neon-green/10 border border-neon-green/30 text-neon-green"
                          : "bg-dark-bg border border-dark-border text-gray-400 hover:text-white"
                      }`}
                    >
                      <div className={`w-4 h-4 rounded border ${customMsgTargets.includes(g.id) ? "bg-neon-green border-neon-green" : "border-gray-500"} flex items-center justify-center`}>
                        {customMsgTargets.includes(g.id) && <CheckCircle2 className="w-3 h-3 text-dark-bg" />}
                      </div>
                      {g.name} <span className="text-gray-500 text-xs">({g.phone})</span>
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={sendCustomMessage}
                disabled={!customMsgText || customMsgTargets.length === 0 || processing}
                className="touch-btn w-full bg-neon-green text-dark-bg font-bold py-3 rounded-lg text-sm flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                Enviar a {customMsgTargets.length} acudiente(s)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Guardians Directory */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-athletic-blue" /> Directorio de Acudientes
          </h3>
          <button
            onClick={() => { resetGuardianForm(); setShowGuardianForm(true); }}
            className="touch-btn bg-athletic-blue/20 text-athletic-blue px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 hover:bg-athletic-blue/30"
          >
            <UserPlus className="w-3 h-3" /> Nuevo
          </button>
        </div>

        {/* Guardian Form Modal */}
        {showGuardianForm && (
          <div className="bg-dark-bg rounded-lg p-3 border border-dark-border space-y-2 mb-3">
            <p className="text-xs text-athletic-blue font-medium">
              {editingGuardian ? "Editar Acudiente" : "Nuevo Acudiente"}
            </p>
            <input
              type="text"
              value={gName}
              onChange={(e) => setGName(e.target.value)}
              placeholder="Nombre completo"
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
            />
            <input
              type="tel"
              value={gPhone}
              onChange={(e) => setGPhone(e.target.value)}
              placeholder="Teléfono (+57...)"
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
            />
            <input
              type="email"
              value={gEmail}
              onChange={(e) => setGEmail(e.target.value)}
              placeholder="Email (opcional)"
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
            />
            <select
              value={gPayment}
              onChange={(e) => setGPayment(e.target.value)}
              className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
            >
              <option value="al_dia">Al día</option>
              <option value="pago_pendiente">Pago pendiente</option>
              <option value="vencido">Vencido</option>
            </select>
            <div className="flex gap-2">
              <button
                onClick={saveGuardian}
                disabled={!gName || !gPhone}
                className="touch-btn flex-1 bg-athletic-blue text-white font-medium py-2 rounded-lg text-sm disabled:opacity-50"
              >
                <Save className="w-4 h-4 inline mr-1" />
                {editingGuardian ? "Actualizar" : "Guardar"}
              </button>
              <button onClick={resetGuardianForm} className="touch-btn px-4 py-2 rounded-lg text-sm text-gray-400 border border-dark-border">
                Cancelar
              </button>
            </div>
          </div>
        )}

        {/* Guardians List */}
        {loading ? (
          <div className="text-center py-4">
            <div className="w-6 h-6 border-2 border-athletic-blue border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : guardians.length === 0 ? (
          <p className="text-gray-500 text-sm text-center py-4">No hay acudientes registrados</p>
        ) : (
          <div className="space-y-2">
            {guardians.map((g) => {
              const playerCount = players.filter((p) => p.guardianId === g.id).length;
              return (
                <div key={g.id} className="bg-dark-bg rounded-lg p-3 border border-dark-border">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-athletic-blue/20 flex items-center justify-center border border-athletic-blue/30">
                        <Phone className="w-4 h-4 text-athletic-blue" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{g.name}</p>
                        <p className="text-xs text-gray-500">{g.phone}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {paymentStatusBadge(g.paymentStatus)}
                      <button onClick={() => editGuardian(g)} className="p-1 text-gray-500 hover:text-athletic-blue">
                        <Edit3 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500">{playerCount} hijo(s)</span>
                    <button
                      onClick={() => openWhatsApp(g.phone, "Hola, le escribo de Pelota y Pasión Academia Deportiva.")}
                      className="touch-btn ml-auto bg-neon-green/10 text-neon-green px-3 py-1 rounded-lg text-xs flex items-center gap-1 hover:bg-neon-green/20"
                    >
                      <Send className="w-3 h-3" /> WhatsApp
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Message History */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
        <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-neon-green" /> Historial de Mensajes
        </h3>
        {messages.length === 0 ? (
          <p className="text-gray-500 text-sm text-center py-4">No hay mensajes enviados</p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {messages.slice().reverse().map((msg) => (
              <div key={msg.id} className="bg-dark-bg rounded-lg p-3 border border-dark-border">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs font-medium text-white">{msg.guardianName}</p>
                    <p className="text-[10px] text-gray-500">
                      {msg.guardianPhone} • {msg.sentVia}
                    </p>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                    msg.status === "enviado" ? "bg-neon-green/10 text-neon-green" :
                    msg.status === "pendiente" ? "bg-gold/10 text-gold" :
                    "bg-red-500/10 text-red-400"
                  }`}>
                    {msg.status}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-1 line-clamp-2">{msg.messageText}</p>
                {msg.status === "pendiente" && msg.guardianPhone && (
                  <button
                    onClick={() => openWhatsApp(msg.guardianPhone!, msg.messageText)}
                    className="touch-btn mt-2 bg-neon-green/10 text-neon-green px-2 py-1 rounded text-[10px] flex items-center gap-1 hover:bg-neon-green/20"
                  >
                    <ExternalLink className="w-3 h-3" /> Enviar por WhatsApp
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
