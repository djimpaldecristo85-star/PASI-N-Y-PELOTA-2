"use client";

import { useState, useEffect, useCallback } from "react";
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  Printer,
  TrendingUp,
  Users,
  ClipboardCheck,
  DollarSign,
  MessageSquare,
  Calendar,
  ChevronDown,
} from "lucide-react";
import { format, subDays, startOfMonth, endOfMonth } from "date-fns";
import { es } from "date-fns/locale";

interface ReportData {
  period: { from: string; to: string };
  players: { total: number; byCategory: Record<string, number> };
  attendance: {
    total: number;
    present: number;
    absent: number;
    excused: number;
    percentage: string;
    byCategory: Record<string, { total: number; present: number }>;
    trainingSessions: number;
  };
  payments: { paid: number; pending: number; overdue: number; total: number };
  messaging: { sent: number; pending: number; total: number };
}

export default function Module4Reports() {
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [fromDate, setFromDate] = useState(format(startOfMonth(new Date()), "yyyy-MM-dd"));
  const [toDate, setToDate] = useState(format(endOfMonth(new Date()), "yyyy-MM-dd"));
  const [showPeriodSelect, setShowPeriodSelect] = useState(false);

  const fetchReport = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/reports?from=${fromDate}&to=${toDate}`);
      const data = await res.json();
      setReport(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [fromDate, toDate]);

  useEffect(() => {
    fetchReport();
  }, [fetchReport]);

  const setQuickPeriod = (period: "thisMonth" | "lastMonth" | "last7" | "last30") => {
    const now = new Date();
    switch (period) {
      case "thisMonth":
        setFromDate(format(startOfMonth(now), "yyyy-MM-dd"));
        setToDate(format(endOfMonth(now), "yyyy-MM-dd"));
        break;
      case "lastMonth": {
        const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        setFromDate(format(startOfMonth(lastMonth), "yyyy-MM-dd"));
        setToDate(format(endOfMonth(lastMonth), "yyyy-MM-dd"));
        break;
      }
      case "last7":
        setFromDate(format(subDays(now, 7), "yyyy-MM-dd"));
        setToDate(format(now, "yyyy-MM-dd"));
        break;
      case "last30":
        setFromDate(format(subDays(now, 30), "yyyy-MM-dd"));
        setToDate(format(now, "yyyy-MM-dd"));
        break;
    }
    setShowPeriodSelect(false);
  };

  const exportCSV = async () => {
    try {
      // Fetch all data for export
      const [playersRes, attendanceRes, guardiansRes] = await Promise.all([
        fetch("/api/players"),
        fetch(`/api/attendance?from=${fromDate}&to=${toDate}`),
        fetch("/api/guardians"),
      ]);

      const playersData = await playersRes.json();
      const attendanceData = await attendanceRes.json();
      const guardiansData = await guardiansRes.json();

      // Build CSV
      const lines: string[] = [];

      // Players section
      lines.push("=== JUGADORES ===");
      lines.push("Nombre,Edad,Categoría,Peso,Altura,IMC,Posición");
      playersData.forEach((p: { name: string; age: number; category: string; weight: string | null; height: string | null; bmi: string | null; position: string | null }) => {
        lines.push(`"${p.name}",${p.age},${p.category},${p.weight || ""},${p.height || ""},${p.bmi || ""},${p.position || ""}`);
      });
      lines.push("");

      // Attendance section
      lines.push("=== ASISTENCIA ===");
      lines.push("Fecha,Jugador,Estado");
      attendanceData.forEach((a: { date: string; playerName?: string; status: string }) => {
        lines.push(`${format(new Date(a.date), "yyyy-MM-dd")},"${a.playerName || ""}",${a.status}`);
      });
      lines.push("");

      // Guardians section
      lines.push("=== ACUDIENTES ===");
      lines.push("Nombre,Teléfono,Estado de Pago");
      guardiansData.forEach((g: { name: string; phone: string; paymentStatus: string }) => {
        lines.push(`"${g.name}","${g.phone}",${g.paymentStatus}`);
      });

      // Download
      const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `pelota_y_pasion_reporte_${fromDate}_${toDate}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    }
  };

  const exportPDF = () => {
    window.print();
  };

  const progressBar = (value: number, max: number, color: string) => (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-dark-border rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full ${color}`}
          style={{ width: `${max > 0 ? (value / max) * 100 : 0}%` }}
        />
      </div>
      <span className="text-xs text-gray-400 w-8 text-right">{value}</span>
    </div>
  );

  return (
    <div className="space-y-4 no-print">
      {/* Module Title */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-neon-green/20 flex items-center justify-center">
          <BarChart3 className="w-4 h-4 text-neon-green" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Reportes y Exportación</h2>
          <p className="text-xs text-gray-500">Métricas consolidadas y descarga de reportes</p>
        </div>
      </div>

      {/* Period Selection */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-athletic-blue" />
            <span className="text-sm font-medium text-white">Período:</span>
          </div>
          <div className="flex flex-wrap gap-2 flex-1">
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="bg-dark-bg border border-dark-border rounded-lg px-3 py-1.5 text-sm text-white focus:border-athletic-blue focus:outline-none"
            />
            <span className="text-gray-500 self-center">a</span>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="bg-dark-bg border border-dark-border rounded-lg px-3 py-1.5 text-sm text-white focus:border-athletic-blue focus:outline-none"
            />
          </div>
          <div className="relative">
            <button
              onClick={() => setShowPeriodSelect(!showPeriodSelect)}
              className="touch-btn bg-athletic-blue/10 text-athletic-blue px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 hover:bg-athletic-blue/20"
            >
              Rápido <ChevronDown className="w-3 h-3" />
            </button>
            {showPeriodSelect && (
              <div className="absolute top-full right-0 mt-1 bg-dark-surface border border-dark-border rounded-lg shadow-xl z-10 py-1 min-w-[160px]">
                <button onClick={() => setQuickPeriod("thisMonth")} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-dark-hover hover:text-white">Este mes</button>
                <button onClick={() => setQuickPeriod("lastMonth")} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-dark-hover hover:text-white">Mes anterior</button>
                <button onClick={() => setQuickPeriod("last7")} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-dark-hover hover:text-white">Últimos 7 días</button>
                <button onClick={() => setQuickPeriod("last30")} className="w-full text-left px-3 py-2 text-sm text-gray-300 hover:bg-dark-hover hover:text-white">Últimos 30 días</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="w-8 h-8 border-2 border-neon-green border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Generando reporte...</p>
        </div>
      ) : !report ? (
        <div className="text-center py-12 bg-dark-surface rounded-xl border border-dark-border">
          <p className="text-gray-400 text-sm">No se pudieron cargar los datos del reporte</p>
        </div>
      ) : (
        <>
          {/* Main Metrics Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Attendance Percentage */}
            <div className="bg-dark-surface rounded-xl border border-neon-green/30 p-4 glow-green">
              <div className="flex items-center gap-2 mb-2">
                <ClipboardCheck className="w-4 h-4 text-neon-green" />
                <span className="text-xs text-gray-500">Asistencia Global</span>
              </div>
              <p className="text-3xl font-bold text-neon-green">{report.attendance.percentage}%</p>
              <p className="text-xs text-gray-500 mt-1">
                {report.attendance.present} de {report.attendance.total} registros
              </p>
            </div>

            {/* Total Players */}
            <div className="bg-dark-surface rounded-xl border border-athletic-blue/30 p-4 glow-blue">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-athletic-blue" />
                <span className="text-xs text-gray-500">Jugadores</span>
              </div>
              <p className="text-3xl font-bold text-athletic-blue">{report.players.total}</p>
              <p className="text-xs text-gray-500 mt-1">
                {Object.keys(report.players.byCategory).length} categorías
              </p>
            </div>

            {/* Payments */}
            <div className="bg-dark-surface rounded-xl border border-gold/30 p-4 glow-gold">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-gold" />
                <span className="text-xs text-gray-500">Cuotas al Día</span>
              </div>
              <p className="text-3xl font-bold text-gold">
                {report.payments.total > 0
                  ? Math.round((report.payments.paid / report.payments.total) * 100)
                  : 0}%
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {report.payments.paid} de {report.payments.total} acudientes
              </p>
            </div>

            {/* Messages */}
            <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="w-4 h-4 text-gray-400" />
                <span className="text-xs text-gray-500">Mensajes Enviados</span>
              </div>
              <p className="text-3xl font-bold text-white">{report.messaging.sent}</p>
              <p className="text-xs text-gray-500 mt-1">
                {report.messaging.pending} pendientes
              </p>
            </div>
          </div>

          {/* Detailed Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Attendance Breakdown */}
            <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-neon-green" /> Asistencia Detallada
              </h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-neon-green">Presentes</span>
                    <span className="text-gray-400">{report.attendance.present}</span>
                  </div>
                  {progressBar(report.attendance.present, report.attendance.total, "bg-neon-green")}
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-red-400">Ausentes</span>
                    <span className="text-gray-400">{report.attendance.absent}</span>
                  </div>
                  {progressBar(report.attendance.absent, report.attendance.total, "bg-red-500")}
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gold">Excusados</span>
                    <span className="text-gray-400">{report.attendance.excused}</span>
                  </div>
                  {progressBar(report.attendance.excused, report.attendance.total, "bg-gold")}
                </div>

                <div className="pt-2 border-t border-dark-border">
                  <p className="text-xs text-gray-500">
                    Sesiones de entrenamiento: <span className="text-white font-medium">{report.attendance.trainingSessions}</span>
                  </p>
                </div>
              </div>

              {/* By Category */}
              {Object.keys(report.attendance.byCategory).length > 0 && (
                <div className="mt-4 pt-3 border-t border-dark-border">
                  <p className="text-xs text-gray-400 mb-2">Por Categoría</p>
                  <div className="space-y-2">
                    {Object.entries(report.attendance.byCategory).map(([cat, data]) => (
                      <div key={cat} className="flex items-center gap-2">
                        <span className="text-xs text-gray-400 w-16">{cat}</span>
                        <div className="flex-1 h-2 bg-dark-border rounded-full overflow-hidden">
                          <div
                            className="h-full bg-athletic-blue rounded-full"
                            style={{ width: `${data.total > 0 ? (data.present / data.total) * 100 : 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500 w-16 text-right">
                          {data.total > 0 ? Math.round((data.present / data.total) * 100) : 0}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Payment & Player Breakdown */}
            <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-gold" /> Estado de Pagos
              </h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-neon-green">Al día</span>
                    <span className="text-gray-400">{report.payments.paid}</span>
                  </div>
                  {progressBar(report.payments.paid, report.payments.total, "bg-neon-green")}
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gold">Pendiente</span>
                    <span className="text-gray-400">{report.payments.pending}</span>
                  </div>
                  {progressBar(report.payments.pending, report.payments.total, "bg-gold")}
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-red-400">Vencido</span>
                    <span className="text-gray-400">{report.payments.overdue}</span>
                  </div>
                  {progressBar(report.payments.overdue, report.payments.total, "bg-red-500")}
                </div>
              </div>

              {/* Players by Category */}
              <div className="mt-4 pt-3 border-t border-dark-border">
                <p className="text-xs text-gray-400 mb-2">Jugadores por Categoría</p>
                <div className="space-y-2">
                  {Object.entries(report.players.byCategory).map(([cat, count]) => (
                    <div key={cat} className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 w-16">{cat}</span>
                      <div className="flex-1 h-2 bg-dark-border rounded-full overflow-hidden">
                        <div
                          className="h-full bg-neon-green rounded-full"
                          style={{ width: `${(count / report.players.total) * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 w-6 text-right">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Export Buttons */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Download className="w-4 h-4 text-neon-green" /> Exportar Reportes
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={exportCSV}
                className="touch-btn bg-neon-green/10 border border-neon-green/30 text-neon-green px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 hover:bg-neon-green/20 transition-all"
              >
                <FileSpreadsheet className="w-5 h-5" />
                Descargar CSV / Excel
              </button>
              <button
                onClick={exportPDF}
                className="touch-btn bg-athletic-blue/10 border border-athletic-blue/30 text-athletic-blue px-4 py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 hover:bg-athletic-blue/20 transition-all"
              >
                <Printer className="w-5 h-5" />
                Imprimir / PDF
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
