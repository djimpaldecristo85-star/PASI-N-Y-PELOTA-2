"use client";

import { Zap, Wifi, WifiOff, Loader2 } from "lucide-react";

interface HeaderProps {
  assistantStatus: "online" | "processing" | "offline";
}

export default function Header({ assistantStatus }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-dark-surface/95 backdrop-blur-md border-b border-dark-border">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16">
          {/* Logo & Academy Name */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="relative">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-neon-green to-athletic-blue flex items-center justify-center glow-green">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-dark-bg" />
              </div>
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold bg-gradient-to-r from-neon-green to-athletic-blue bg-clip-text text-transparent truncate">
                Pelota y Pasión
              </h1>
              <p className="text-[10px] sm:text-xs text-gray-500 font-medium hidden sm:block">
                Academia Deportiva
              </p>
            </div>
          </div>

          {/* Assistant Status Indicator */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div
              className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1.5 rounded-full text-xs font-medium border ${
                assistantStatus === "online"
                  ? "bg-neon-green/10 border-neon-green/30 text-neon-green"
                  : assistantStatus === "processing"
                    ? "bg-gold/10 border-gold/30 text-gold"
                    : "bg-red-500/10 border-red-500/30 text-red-400"
              }`}
            >
              {assistantStatus === "online" && (
                <>
                  <Wifi className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span className="hidden sm:inline">Asistente</span>
                  <span className="sm:hidden">Online</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-pulse-green" />
                </>
              )}
              {assistantStatus === "processing" && (
                <>
                  <Loader2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 animate-spin" />
                  <span>Procesando</span>
                </>
              )}
              {assistantStatus === "offline" && (
                <>
                  <WifiOff className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span>Offline</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
