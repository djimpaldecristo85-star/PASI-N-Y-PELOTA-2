"use client";

import { useState, useEffect, useCallback } from "react";
import {
  UserPlus,
  Search,
  Filter,
  Edit3,
  Trash2,
  Activity,
  Scale,
  Ruler,
  ChevronDown,
  X,
  Save,
  AlertTriangle,
  CheckCircle2,
  Info,
} from "lucide-react";

const CATEGORIES = [
  "Sub-7",
  "Sub-9",
  "Sub-10",
  "Sub-12",
  "Sub-13",
  "Sub-15",
  "Sub-17",
  "Sub-20",
  "Libre",
] as const;

type Category = (typeof CATEGORIES)[number];

interface Player {
  id: string;
  name: string;
  age: number;
  category: Category;
  weight: string | null;
  height: string | null;
  bmi: string | null;
  guardianId: string | null;
  position: string | null;
  guardian?: { id: string; name: string; phone: string; paymentStatus: string } | null;
}

interface Guardian {
  id: string;
  name: string;
  phone: string;
  email?: string;
  paymentStatus: string;
}

function getBmiCategory(bmi: number): { label: string; color: string; icon: typeof Info } {
  if (bmi < 18.5) return { label: "Bajo peso", color: "text-athletic-blue", icon: Info };
  if (bmi < 25) return { label: "Normal", color: "text-neon-green", icon: CheckCircle2 };
  if (bmi < 30) return { label: "Sobrepeso", color: "text-gold", icon: AlertTriangle };
  return { label: "Obesidad", color: "text-red-400", icon: AlertTriangle };
}

export default function Module1Players() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [guardians, setGuardians] = useState<Guardian[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [showForm, setShowForm] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [showGuardianForm, setShowGuardianForm] = useState(false);

  // Form state
  const [formName, setFormName] = useState("");
  const [formAge, setFormAge] = useState("");
  const [formCategory, setFormCategory] = useState<Category>("Sub-10");
  const [formWeight, setFormWeight] = useState("");
  const [formHeight, setFormHeight] = useState("");
  const [formPosition, setFormPosition] = useState("");
  const [formGuardianId, setFormGuardianId] = useState("");

  // Guardian form state
  const [gName, setGName] = useState("");
  const [gPhone, setGPhone] = useState("");
  const [gEmail, setGEmail] = useState("");

  // BMI calculator
  const [bmiWeight, setBmiWeight] = useState("");
  const [bmiHeight, setBmiHeight] = useState("");
  const [bmiResult, setBmiResult] = useState<number | null>(null);

  const fetchPlayers = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (filterCategory) params.set("category", filterCategory);
      const res = await fetch(`/api/players?${params}`);
      const data = await res.json();
      setPlayers(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [search, filterCategory]);

  const fetchGuardians = useCallback(async () => {
    try {
      const res = await fetch("/api/guardians");
      const data = await res.json();
      setGuardians(data);
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    fetchPlayers();
    fetchGuardians();
  }, [fetchPlayers, fetchGuardians]);

  // Instant BMI calculation
  useEffect(() => {
    if (bmiWeight && bmiHeight) {
      const w = parseFloat(bmiWeight);
      const h = parseFloat(bmiHeight) / 100;
      if (w > 0 && h > 0) {
        setBmiResult(parseFloat((w / (h * h)).toFixed(1)));
      }
    } else {
      setBmiResult(null);
    }
  }, [bmiWeight, bmiHeight]);

  const resetForm = () => {
    setFormName("");
    setFormAge("");
    setFormCategory("Sub-10");
    setFormWeight("");
    setFormHeight("");
    setFormPosition("");
    setFormGuardianId("");
    setEditingPlayer(null);
    setShowForm(false);
  };

  const handleSavePlayer = async () => {
    if (!formName || !formAge) return;

    const body = {
      name: formName,
      age: parseInt(formAge),
      category: formCategory,
      weight: formWeight || null,
      height: formHeight || null,
      position: formPosition || null,
      guardianId: formGuardianId || null,
    };

    try {
      if (editingPlayer) {
        await fetch("/api/players", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...body, id: editingPlayer.id }),
        });
      } else {
        await fetch("/api/players", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
      }
      resetForm();
      fetchPlayers();
    } catch (err) {
      console.error(err);
    }
  };

  const handleEdit = (player: Player) => {
    setEditingPlayer(player);
    setFormName(player.name);
    setFormAge(String(player.age));
    setFormCategory(player.category);
    setFormWeight(player.weight || "");
    setFormHeight(player.height || "");
    setFormPosition(player.position || "");
    setFormGuardianId(player.guardianId || "");
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar este jugador?")) return;
    try {
      await fetch(`/api/players?id=${id}`, { method: "DELETE" });
      fetchPlayers();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSaveGuardian = async () => {
    if (!gName || !gPhone) return;
    try {
      const res = await fetch("/api/guardians", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: gName, phone: gPhone, email: gEmail }),
      });
      const newGuardian = await res.json();
      setGuardians((prev) => [...prev, newGuardian]);
      setFormGuardianId(newGuardian.id);
      setGName("");
      setGPhone("");
      setGEmail("");
      setShowGuardianForm(false);
    } catch (err) {
      console.error(err);
    }
  };

  const filteredPlayers = players;

  return (
    <div className="space-y-4">
      {/* Module Title */}
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-neon-green/20 flex items-center justify-center">
          <Activity className="w-4 h-4 text-neon-green" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Gestión de Jugadores</h2>
          <p className="text-xs text-gray-500">Control de IMC y Categorías</p>
        </div>
      </div>

      {/* BMI Calculator - Quick Access */}
      <div className="bg-dark-surface rounded-xl border border-dark-border p-4 glow-green">
        <h3 className="text-sm font-semibold text-neon-green mb-3 flex items-center gap-2">
          <Scale className="w-4 h-4" /> Calculadora Rápida de IMC
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Peso (kg)</label>
            <input
              type="number"
              value={bmiWeight}
              onChange={(e) => setBmiWeight(e.target.value)}
              placeholder="45"
              className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-neon-green focus:outline-none"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Talla (cm)</label>
            <input
              type="number"
              value={bmiHeight}
              onChange={(e) => setBmiHeight(e.target.value)}
              placeholder="145"
              className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-neon-green focus:outline-none"
            />
          </div>
          <div className="col-span-2 flex items-end">
            {bmiResult ? (
              <div className="flex items-center gap-3 w-full bg-dark-bg rounded-lg px-4 py-2 border border-dark-border">
                <span className="text-2xl font-bold text-neon-green">{bmiResult}</span>
                {(() => {
                  const cat = getBmiCategory(bmiResult);
                  const Icon = cat.icon;
                  return (
                    <span className={`text-sm font-medium ${cat.color} flex items-center gap-1`}>
                      <Icon className="w-4 h-4" /> {cat.label}
                    </span>
                  );
                })()}
              </div>
            ) : (
              <div className="w-full bg-dark-bg rounded-lg px-4 py-2 border border-dark-border text-sm text-gray-500">
                Ingrese peso y talla para calcular
              </div>
            )}
          </div>
        </div>
        {/* BMI Scale */}
        <div className="mt-3 flex items-center gap-1 text-[10px]">
          <div className="flex-1 h-2 rounded-l-full bg-athletic-blue" />
          <div className="flex-1 h-2 bg-neon-green" />
          <div className="flex-1 h-2 bg-gold" />
          <div className="flex-1 h-2 rounded-r-full bg-red-500" />
          <span className="ml-2 text-gray-500">Bajo</span>
          <span className="mx-1 text-gray-600">|</span>
          <span className="text-gray-500">Normal</span>
          <span className="mx-1 text-gray-600">|</span>
          <span className="text-gray-500">Sobrepeso</span>
          <span className="mx-1 text-gray-600">|</span>
          <span className="text-gray-500">Obesidad</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar jugador..."
            className="w-full bg-dark-surface border border-dark-border rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:border-neon-green focus:outline-none"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-dark-surface border border-dark-border rounded-lg pl-10 pr-8 py-2.5 text-sm text-white appearance-none focus:border-neon-green focus:outline-none"
          >
            <option value="">Todas las categorías</option>
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="touch-btn bg-neon-green text-dark-bg font-semibold px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 hover:bg-neon-green-dim transition-smooth"
        >
          <UserPlus className="w-4 h-4" />
          <span className="sm:inline">Nuevo</span>
        </button>
      </div>

      {/* Player Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-dark-surface rounded-2xl border border-dark-border w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-dark-border">
              <h3 className="font-bold text-white">
                {editingPlayer ? "Editar Jugador" : "Nuevo Jugador"}
              </h3>
              <button onClick={resetForm} className="text-gray-500 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Nombre completo *</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                  placeholder="Nombre del jugador"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Edad *</label>
                  <input
                    type="number"
                    value={formAge}
                    onChange={(e) => setFormAge(e.target.value)}
                    className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                    placeholder="12"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block">Categoría *</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as Category)}
                    className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-400 mb-1 block flex items-center gap-1">
                    <Scale className="w-3 h-3" /> Peso (kg)
                  </label>
                  <input
                    type="number"
                    value={formWeight}
                    onChange={(e) => setFormWeight(e.target.value)}
                    className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                    placeholder="45.5"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-400 mb-1 block flex items-center gap-1">
                    <Ruler className="w-3 h-3" /> Talla (cm)
                  </label>
                  <input
                    type="number"
                    value={formHeight}
                    onChange={(e) => setFormHeight(e.target.value)}
                    className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                    placeholder="145"
                  />
                </div>
              </div>
              {/* Live BMI in form */}
              {formWeight && formHeight && (() => {
                const w = parseFloat(formWeight);
                const h = parseFloat(formHeight) / 100;
                if (w > 0 && h > 0) {
                  const bmi = w / (h * h);
                  const cat = getBmiCategory(bmi);
                  const Icon = cat.icon;
                  return (
                    <div className="bg-dark-bg rounded-lg px-3 py-2 border border-dark-border flex items-center gap-2">
                      <span className="text-xs text-gray-400">IMC:</span>
                      <span className="font-bold text-neon-green">{bmi.toFixed(1)}</span>
                      <span className={`text-xs flex items-center gap-1 ${cat.color}`}>
                        <Icon className="w-3 h-3" /> {cat.label}
                      </span>
                    </div>
                  );
                }
                return null;
              })()}
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Posición</label>
                <input
                  type="text"
                  value={formPosition}
                  onChange={(e) => setFormPosition(e.target.value)}
                  className="w-full bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                  placeholder="Delantero, Portero, etc."
                />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Acudiente</label>
                <div className="flex gap-2">
                  <select
                    value={formGuardianId}
                    onChange={(e) => setFormGuardianId(e.target.value)}
                    className="flex-1 bg-dark-bg border border-dark-border rounded-lg px-3 py-2.5 text-sm text-white focus:border-neon-green focus:outline-none"
                  >
                    <option value="">Sin acudiente</option>
                    {guardians.map((g) => (
                      <option key={g.id} value={g.id}>{g.name}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => setShowGuardianForm(!showGuardianForm)}
                    className="touch-btn bg-athletic-blue/20 text-athletic-blue px-3 rounded-lg text-sm hover:bg-athletic-blue/30"
                  >
                    <UserPlus className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {showGuardianForm && (
                <div className="bg-dark-bg rounded-lg p-3 border border-dark-border space-y-2">
                  <p className="text-xs text-athletic-blue font-medium">Nuevo Acudiente</p>
                  <input
                    type="text"
                    value={gName}
                    onChange={(e) => setGName(e.target.value)}
                    placeholder="Nombre del acudiente"
                    className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
                  />
                  <input
                    type="tel"
                    value={gPhone}
                    onChange={(e) => setGPhone(e.target.value)}
                    placeholder="Teléfono (+57...)"
                    className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
                  />
                  <input
                    type="email"
                    value={gEmail}
                    onChange={(e) => setGEmail(e.target.value)}
                    placeholder="Email (opcional)"
                    className="w-full bg-dark-surface border border-dark-border rounded-lg px-3 py-2 text-sm text-white focus:border-athletic-blue focus:outline-none"
                  />
                  <button
                    onClick={handleSaveGuardian}
                    disabled={!gName || !gPhone}
                    className="touch-btn w-full bg-athletic-blue text-white font-medium py-2 rounded-lg text-sm disabled:opacity-50"
                  >
                    Guardar Acudiente
                  </button>
                </div>
              )}
              <button
                onClick={handleSavePlayer}
                disabled={!formName || !formAge}
                className="touch-btn w-full bg-neon-green text-dark-bg font-bold py-3 rounded-lg text-sm flex items-center justify-center gap-2 disabled:opacity-50 hover:bg-neon-green-dim transition-smooth"
              >
                <Save className="w-4 h-4" />
                {editingPlayer ? "Actualizar Jugador" : "Guardar Jugador"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Players Grid */}
      {loading ? (
        <div className="text-center py-12">
          <div className="w-8 h-8 border-2 border-neon-green border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Cargando jugadores...</p>
        </div>
      ) : filteredPlayers.length === 0 ? (
        <div className="text-center py-12 bg-dark-surface rounded-xl border border-dark-border">
          <UserPlus className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 text-sm">
            {search || filterCategory
              ? "No se encontraron jugadores con esos filtros"
              : "No hay jugadores registrados. ¡Agrega el primero!"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredPlayers.map((player) => (
            <div
              key={player.id}
              className="bg-dark-surface rounded-xl border border-dark-border p-4 card-hover"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-neon-green/20 to-athletic-blue/20 flex items-center justify-center border border-dark-border">
                    <span className="text-sm font-bold text-neon-green">
                      {player.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm">{player.name}</h4>
                    <p className="text-xs text-gray-500">
                      {player.age} años • {player.category}
                    </p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => handleEdit(player)}
                    className="p-1.5 text-gray-500 hover:text-athletic-blue rounded-md hover:bg-athletic-blue/10"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(player.id)}
                    className="p-1.5 text-gray-500 hover:text-red-400 rounded-md hover:bg-red-500/10"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-2 mb-2">
                <div className="bg-dark-bg rounded-lg px-2 py-1.5 text-center">
                  <p className="text-[10px] text-gray-500">Peso</p>
                  <p className="text-xs font-semibold text-white">
                    {player.weight ? `${player.weight}kg` : "—"}
                  </p>
                </div>
                <div className="bg-dark-bg rounded-lg px-2 py-1.5 text-center">
                  <p className="text-[10px] text-gray-500">Talla</p>
                  <p className="text-xs font-semibold text-white">
                    {player.height ? `${player.height}cm` : "—"}
                  </p>
                </div>
                <div className="bg-dark-bg rounded-lg px-2 py-1.5 text-center">
                  <p className="text-[10px] text-gray-500">IMC</p>
                  {player.bmi ? (
                    <p className={`text-xs font-semibold ${getBmiCategory(parseFloat(player.bmi)).color}`}>
                      {player.bmi}
                    </p>
                  ) : (
                    <p className="text-xs font-semibold text-gray-600">—</p>
                  )}
                </div>
              </div>

              {/* Position & Guardian */}
              <div className="flex items-center justify-between text-xs">
                {player.position && (
                  <span className="bg-athletic-blue/10 text-athletic-blue px-2 py-0.5 rounded-full">
                    {player.position}
                  </span>
                )}
                {player.guardian && (
                  <span className="text-gray-500 truncate ml-2">
                    👨‍👩‍👦 {player.guardian.name}
                  </span>
                )}
                {player.guardian && player.guardian.paymentStatus !== "al_dia" && (
                  <span className="bg-gold/10 text-gold px-2 py-0.5 rounded-full ml-1">
                    Cuota pend.
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Summary Stats */}
      {players.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="bg-dark-surface rounded-xl border border-dark-border p-3 text-center">
            <p className="text-2xl font-bold text-neon-green">{players.length}</p>
            <p className="text-xs text-gray-500">Total Jugadores</p>
          </div>
          <div className="bg-dark-surface rounded-xl border border-dark-border p-3 text-center">
            <p className="text-2xl font-bold text-athletic-blue">
              {new Set(players.map((p) => p.category)).size}
            </p>
            <p className="text-xs text-gray-500">Categorías</p>
          </div>
          <div className="bg-dark-surface rounded-xl border border-dark-border p-3 text-center">
            <p className="text-2xl font-bold text-gold">{guardians.length}</p>
            <p className="text-xs text-gray-500">Acudientes</p>
          </div>
          <div className="bg-dark-surface rounded-xl border border-dark-border p-3 text-center">
            <p className="text-2xl font-bold text-white">
              {players.filter((p) => p.bmi).length > 0
                ? (
                    players
                      .filter((p) => p.bmi)
                      .reduce((sum, p) => sum + parseFloat(p.bmi!), 0) /
                    players.filter((p) => p.bmi).length
                  ).toFixed(1)
                : "—"}
            </p>
            <p className="text-xs text-gray-500">IMC Promedio</p>
          </div>
        </div>
      )}
    </div>
  );
}
